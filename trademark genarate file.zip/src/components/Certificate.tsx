import { forwardRef } from 'react'
import type { CertData } from '../data'
import StampSeal from './StampSeal'
import WatermarkMark from './WatermarkMark'
import crestUrl from '../assets/crest.png'

interface CertificateProps {
  data: CertData
}

/** A4 sheet (794 x 1123 px @ 96dpi) replicating the registration certificate — all content on one page. */
export const Certificate = forwardRef<HTMLDivElement, CertificateProps>(function Certificate(
  { data },
  ref,
) {
  return (
    <div
      ref={ref}
      id="cert-sheet"
      className="relative bg-[#fbfbf7] text-[#1d1d1f]"
      style={{
        width: 794,
        height: 1123,
        overflow: 'hidden',
        fontFamily: "'Times New Roman', Times, serif",
      }}
    >
      {/* Watermark — D&CRA authority mark, centered on the exact middle point of the page */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 z-0 h-[400px] w-[660px] -translate-x-1/2 -translate-y-1/2 select-none">
        <WatermarkMark text={data.watermark} />
      </div>

      <div className="relative z-10 flex h-full flex-col items-center px-[54px] pt-[8px]">
        {/* Coat of arms */}
        <img
          src={crestUrl}
          alt="Coat of arms"
          draggable={false}
          className="h-[66px] w-auto object-contain"
        />

        <p className="mt-1.5 text-[15px] font-bold">{data.actLine}</p>

        <h1
          className="mt-3 text-center text-[32px] leading-none text-[#232328]"
          style={{ fontFamily: "'Cinzel', 'Times New Roman', serif", fontWeight: 900, letterSpacing: '2.5px' }}
        >
          {data.officeLine1}
        </h1>
        <p
          className="mt-1.5 text-center text-[21px] leading-none text-[#2c2c31]"
          style={{ fontFamily: "'Cinzel', 'Times New Roman', serif", fontWeight: 500, letterSpacing: '6px' }}
        >
          {data.officeLine2}
        </p>

        <h2 className="mt-6 text-center text-[21px] font-bold" style={{ letterSpacing: '1.5px' }}>
          {data.certTitle}
        </h2>

        <p className="mt-3 w-full text-left text-[17px] leading-[1.55]" style={{ textIndent: '2.4em' }}>
          This is to certify that <strong>{data.company}</strong> {data.companiesAct} whose trade or
          business address is at <strong>{data.address}</strong>, was
          entered on the Register of Trade Marks as Proprietor of the Trade Mark No.&nbsp;
          <strong>{data.tmNumber}</strong> in respect of:-
        </p>

        <div className="mt-2.5 w-full pl-[52px] pr-[6px] text-left text-[16px] leading-[1.5]">
          <p>
            "{data.goods}" for the registration of which application was made on{' '}
            <strong>{data.appliedDate}.</strong>
          </p>
        </div>

        <p className="mt-3 w-full pl-[52px] text-left text-[17px]">
          This Trade Mark remains in force until{' '}
          <strong className="underline">{data.expiryDate}.</strong>
        </p>

        <p className="mt-2.5 w-full pl-[52px] text-left text-[17px]">
          A representation of the said Trade Mark is shown hereunder.
        </p>

        <p className="mt-2.5 w-full pl-[52px] pr-[6px] text-left text-[17px] leading-[1.55]">
          Registration of this trademark shall give no right to the exclusive use of the individual
          words "{data.reservedWords}" {data.reservedNote}
        </p>

        {/* Trade mark representation */}
        <div className="mt-3 flex min-h-[60px] w-full flex-1 items-start justify-center overflow-hidden">
          {data.markImage ? (
            <img
              src={data.markImage}
              alt="Trade mark"
              className="mt-2 max-h-[170px] max-w-[440px] object-contain"
            />
          ) : (
            <div className="mt-4 text-center">
              <div className="relative inline-block px-1">
                <span
                  className="logo-font leading-none text-[#3a3e45]"
                  style={{
                    letterSpacing: '-1px',
                    fontSize: Math.min(54, Math.floor(640 / (Math.max(1, data.markLine1.length) * 0.68))),
                  }}
                >
                  {data.markLine1}
                </span>
                <span className="absolute left-[49%] right-[2%] top-[3px] h-[5px] bg-[#3a3e45]" />
              </div>
              <div
                className="mt-2 text-[23px] font-semibold text-[#494d54]"
                style={{
                  fontFamily: "Arial, Helvetica, sans-serif",
                  letterSpacing: '0.55em',
                  marginRight: '-0.55em',
                }}
              >
                {data.markLine2}
              </div>
            </div>
          )}
        </div>

        {/* Execution block */}
        <div className="mb-[28px] mt-2 flex w-full items-end justify-between">
          <div className="relative h-[140px] w-[430px] shrink-0">
            <div
              className="absolute bottom-[-2px] left-0 -rotate-[7deg] opacity-[0.9]"
              style={{ mixBlendMode: 'multiply' }}
            >
              {data.sealImage ? (
                <img
                  src={data.sealImage}
                  alt="Seal"
                  draggable={false}
                  className="h-[170px] w-[170px] object-contain"
                />
              ) : (
                <StampSeal crest={crestUrl} />
              )}
            </div>
            {/* Date touching the right side of the seal */}
            <div className="absolute left-[176px] top-[40px]">
              <div className="text-[13.5px] font-semibold text-[#3a3a3a]">Date</div>
              <div className="mt-0.5 text-[15px] font-bold">{data.stampDate}</div>
            </div>
          </div>

          <div className="w-[320px] text-center">
            {data.signatureImage ? (
              <img
                src={data.signatureImage}
                alt="Signature"
                draggable={false}
                className="mx-auto -mb-1.5 max-h-[46px] max-w-[250px] object-contain"
              />
            ) : (
              <div
                className="-mb-1 translate-x-3 text-[46px] leading-[1.1] text-[#191a1f]"
                style={{ fontFamily: "'Dancing Script', cursive", fontWeight: 600 }}
              >
                {data.signatory}
              </div>
            )}
            <div className="border-t border-[#2c2c2c] pt-1.5 text-[14.5px]">{data.signatoryTitle}</div>
          </div>
        </div>
      </div>
    </div>
  )
})
