interface WatermarkMarkProps {
  text: string
}

/**
 * Faint recreation of the Deeds & Commercial Registries Authority mark:
 * D·C·R·A serif monogram, crescent swoosh, bridge motif and the
 * curved authority name — rendered in a single light watermark tone.
 */
export default function WatermarkMark({ text }: WatermarkMarkProps) {
  const dark = 'rgba(45,48,58,0.095)'
  const light = 'rgba(45,48,58,0.06)'

  return (
    <svg viewBox="0 0 660 400" className="h-full w-full select-none">
      <defs>
        <path id="wm-banner" d="M 85 315 Q 330 405 595 295" fill="none" />
      </defs>

      {/* Monogram: D & C (dark tone), R & A (light tone) */}
      <g fontFamily="'Times New Roman', Times, serif" fontWeight="700">
        <text x="118" y="252" fontSize="240" fill={dark}>
          D
        </text>
        <text x="160" y="330" fontSize="215" fill={dark}>
          C
        </text>
        <text x="285" y="210" fontSize="200" fill={light}>
          R
        </text>
        <text x="415" y="230" fontSize="200" fill={light}>
          A
        </text>
      </g>

      {/* Right crescent swoosh */}
      <path d="M 540 45 A 235 235 0 0 1 605 295 A 300 300 0 0 0 540 45 Z" fill={dark} />

      {/* Left swoosh under the D */}
      <path d="M 30 235 Q 130 265 230 245 Q 130 285 30 253 Z" fill={light} />

      {/* Bridge motif */}
      <g stroke={dark} fill="none" strokeLinecap="round">
        <path d="M 210 308 L 452 296" strokeWidth="7" />
        <path d="M 250 310 L 250 332" strokeWidth="6" />
        <path d="M 310 308 L 310 330" strokeWidth="6" />
        <path d="M 370 305 L 370 327" strokeWidth="6" />
        <path d="M 430 303 L 430 325" strokeWidth="6" />
      </g>

      {/* Curved authority name */}
      <text
        fontSize="21"
        letterSpacing="0.5"
        fill={dark}
        fontFamily="Arial, Helvetica, sans-serif"
        fontWeight="700"
      >
        <textPath href="#wm-banner" startOffset="50%" textAnchor="middle">
          {text}
        </textPath>
      </text>
    </svg>
  )
}
