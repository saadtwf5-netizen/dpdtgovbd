interface StampSealProps {
  crest: string
}

/**
 * Circular blue Commercial Registry seal — "THE COMMERCIAL REGISTRY" outer
 * ring, "INTELLECTUAL PROPERTY" arc above the crest, straight "OFFICE"
 * beneath it, and "GUYANA" on the bottom arc.
 */
export default function StampSeal({ crest }: StampSealProps) {
  const BLUE = '#1a44bd'

  return (
    <div className="relative h-[170px] w-[170px] select-none">
      <svg viewBox="0 0 220 220" className="h-full w-full">
        <defs>
          <path id="seal-arc-top" d="M 28,110 A 82,82 0 0 1 192,110" fill="none" />
          <path id="seal-arc-bottom" d="M 28,110 A 82,82 0 0 0 192,110" fill="none" />
          <path id="seal-arc-top-in" d="M 52,110 A 58,58 0 0 1 168,110" fill="none" />
        </defs>

        <g fill="none" stroke={BLUE}>
          <circle cx="110" cy="110" r="106" strokeWidth="4.5" />
          <circle cx="110" cy="110" r="94" strokeWidth="1.2" />
          <circle cx="110" cy="110" r="70" strokeWidth="2.2" />
        </g>

        <g fill={BLUE} fontFamily="Arial, Helvetica, sans-serif">
          <text fontSize="14" fontWeight="800" letterSpacing="1.2">
            <textPath href="#seal-arc-top" startOffset="50%" textAnchor="middle">
              THE COMMERCIAL REGISTRY
            </textPath>
          </text>
          <text fontSize="24" fontWeight="800" letterSpacing="8">
            <textPath href="#seal-arc-bottom" startOffset="50%" textAnchor="middle">
              GUYANA
            </textPath>
          </text>
          <text fontSize="10.5" fontWeight="700" letterSpacing="1">
            <textPath href="#seal-arc-top-in" startOffset="50%" textAnchor="middle">
              INTELLECTUAL PROPERTY
            </textPath>
          </text>
          <text x="110" y="164" fontSize="14" fontWeight="800" letterSpacing="4" textAnchor="middle">
            OFFICE
          </text>
        </g>
      </svg>

      <img
        src={crest}
        alt=""
        draggable={false}
        className="absolute left-1/2 top-1/2 h-[66px] w-[56px] -translate-x-1/2 -translate-y-1/2 object-contain"
        style={{ filter: 'grayscale(1) brightness(0.5) sepia(1) hue-rotate(188deg) saturate(3.4)' }}
      />
    </div>
  )
}
