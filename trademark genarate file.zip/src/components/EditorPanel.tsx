import { useRef, type ReactNode } from 'react'
import type { CertData } from '../data'

interface EditorPanelProps {
  data: CertData
  onField: (key: keyof CertData, value: string) => void
  onLogo: (file: File) => void
  onLogoClear: () => void
  onSeal: (file: File) => void
  onSealClear: () => void
  onSignature: (file: File) => void
  onSignatureClear: () => void
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="border-b border-[#1e2026] px-5 py-5">
      <h3 className="mb-3.5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-[#99a1ad]">
        <span className="h-[5px] w-[5px] rounded-full bg-[#c9932f]" />
        {title}
      </h3>
      <div className="space-y-3.5">{children}</div>
    </section>
  )
}

function Field({
  label,
  value,
  onChange,
  textarea,
  rows = 3,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  textarea?: boolean
  rows?: number
}) {
  const base =
    'w-full rounded-md border border-[#2a2d35] bg-[#1b1d23] px-3 py-2 text-[13px] leading-relaxed text-[#e9e7e1] outline-none transition placeholder:text-[#5c616c] focus:border-[#c9932f] focus:ring-2 focus:ring-[#c9932f]/25'
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-[#b8bdc6]">{label}</span>
      {textarea ? (
        <textarea rows={rows} value={value} onChange={(e) => onChange(e.target.value)} className={base + ' resize-y'} />
      ) : (
        <input value={value} onChange={(e) => onChange(e.target.value)} className={base} />
      )}
    </label>
  )
}

export default function EditorPanel({
  data,
  onField,
  onLogo,
  onLogoClear,
  onSeal,
  onSealClear,
  onSignature,
  onSignatureClear,
}: EditorPanelProps) {
  const fileRef = useRef<HTMLInputElement>(null)
  const sealFileRef = useRef<HTMLInputElement>(null)
  const signatureFileRef = useRef<HTMLInputElement>(null)

  return (
    <div className="flex h-full flex-col">
      <div className="flex-1 overflow-y-auto">
        <Section title="Document Header">
          <Field label="Act reference" value={data.actLine} onChange={(v) => onField('actLine', v)} />
          <Field
            label="Office — line 1"
            value={data.officeLine1}
            onChange={(v) => onField('officeLine1', v)}
          />
          <Field
            label="Office — line 2"
            value={data.officeLine2}
            onChange={(v) => onField('officeLine2', v)}
          />
          <Field label="Certificate title" value={data.certTitle} onChange={(v) => onField('certTitle', v)} />
          <Field label="Watermark" value={data.watermark} onChange={(v) => onField('watermark', v)} />
        </Section>

        <Section title="Proprietor">
          <Field label="Company name" value={data.company} onChange={(v) => onField('company', v)} />
          <Field
            label="Registration clause (exact wording)"
            value={data.companiesAct}
            onChange={(v) => onField('companiesAct', v)}
          />
          <Field
            label="Trade / business address"
            value={data.address}
            onChange={(v) => onField('address', v)}
            textarea
            rows={2}
          />
        </Section>

        <Section title="Trade Mark">
          <div className="grid grid-cols-2 gap-3">
            <Field label="TM Number" value={data.tmNumber} onChange={(v) => onField('tmNumber', v)} />
            <Field label="Application date" value={data.appliedDate} onChange={(v) => onField('appliedDate', v)} />
          </div>
          <Field label="In force until" value={data.expiryDate} onChange={(v) => onField('expiryDate', v)} />
          <Field
            label="Goods / services description"
            value={data.goods}
            onChange={(v) => onField('goods', v)}
            textarea
            rows={7}
          />
          <Field
            label="Reserved words (no exclusive use)"
            value={data.reservedWords}
            onChange={(v) => onField('reservedWords', v)}
          />
          <Field
            label="Reserved words — closing note"
            value={data.reservedNote}
            onChange={(v) => onField('reservedNote', v)}
          />
        </Section>

        <Section title="Mark Representation">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Logo wordmark" value={data.markLine1} onChange={(v) => onField('markLine1', v)} />
            <Field label="Logo subtitle" value={data.markLine2} onChange={(v) => onField('markLine2', v)} />
          </div>
          <div>
            <span className="mb-1.5 block text-xs font-medium text-[#b8bdc6]">
              Mark image <span className="text-[#6b707b]">(optional — replaces wordmark)</span>
            </span>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) onLogo(f)
                e.target.value = ''
              }}
            />
            {data.markImage ? (
              <div className="flex items-center gap-3 rounded-md border border-[#2a2d35] bg-[#1b1d23] p-2.5">
                <img src={data.markImage} alt="Mark" className="h-12 w-20 rounded bg-white object-contain p-1" />
                <div className="flex flex-1 gap-2">
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    className="flex-1 rounded border border-[#343843] px-2 py-1.5 text-xs font-medium text-[#cfd3da] transition hover:border-[#c9932f]/60 hover:text-white"
                  >
                    Replace
                  </button>
                  <button
                    type="button"
                    onClick={onLogoClear}
                    className="flex-1 rounded border border-[#4a2c2c] px-2 py-1.5 text-xs font-medium text-[#e09a8a] transition hover:border-[#e0684a] hover:text-[#ff9d85]"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="w-full rounded-md border border-dashed border-[#3a3e49] bg-[#171920] px-3 py-4 text-xs font-medium text-[#8f95a1] transition hover:border-[#c9932f]/70 hover:text-[#d8c9a5]"
              >
                + Upload trade mark logo (PNG / JPG)
              </button>
            )}
          </div>
        </Section>

        <Section title="Execution">
          <div>
            <span className="mb-1.5 block text-xs font-medium text-[#b8bdc6]">
              Seal image <span className="text-[#6b707b]">(optional — replaces built-in seal)</span>
            </span>
            <input
              ref={sealFileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) onSeal(f)
                e.target.value = ''
              }}
            />
            {data.sealImage ? (
              <div className="flex items-center gap-3 rounded-md border border-[#2a2d35] bg-[#1b1d23] p-2.5">
                <img
                  src={data.sealImage}
                  alt="Seal"
                  className="h-12 w-12 rounded bg-white object-contain p-1"
                />
                <div className="flex flex-1 gap-2">
                  <button
                    type="button"
                    onClick={() => sealFileRef.current?.click()}
                    className="flex-1 rounded border border-[#343843] px-2 py-1.5 text-xs font-medium text-[#cfd3da] transition hover:border-[#c9932f]/60 hover:text-white"
                  >
                    Replace
                  </button>
                  <button
                    type="button"
                    onClick={onSealClear}
                    className="flex-1 rounded border border-[#4a2c2c] px-2 py-1.5 text-xs font-medium text-[#e09a8a] transition hover:border-[#e0684a] hover:text-[#ff9d85]"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => sealFileRef.current?.click()}
                className="w-full rounded-md border border-dashed border-[#3a3e49] bg-[#171920] px-3 py-4 text-xs font-medium text-[#8f95a1] transition hover:border-[#c9932f]/70 hover:text-[#d8c9a5]"
              >
                + Upload seal image (PNG / JPG)
              </button>
            )}
          </div>
          <Field label="Seal date" value={data.stampDate} onChange={(v) => onField('stampDate', v)} />
          <Field label="Signatory name" value={data.signatory} onChange={(v) => onField('signatory', v)} />
          <Field
            label="Signatory title"
            value={data.signatoryTitle}
            onChange={(v) => onField('signatoryTitle', v)}
          />
          <div>
            <span className="mb-1.5 block text-xs font-medium text-[#b8bdc6]">
              Signature image <span className="text-[#6b707b]">(optional — replaces written name)</span>
            </span>
            <input
              ref={signatureFileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) onSignature(f)
                e.target.value = ''
              }}
            />
            {data.signatureImage ? (
              <div className="flex items-center gap-3 rounded-md border border-[#2a2d35] bg-[#1b1d23] p-2.5">
                <img
                  src={data.signatureImage}
                  alt="Signature"
                  className="h-10 w-24 rounded bg-white object-contain p-1"
                />
                <div className="flex flex-1 gap-2">
                  <button
                    type="button"
                    onClick={() => signatureFileRef.current?.click()}
                    className="flex-1 rounded border border-[#343843] px-2 py-1.5 text-xs font-medium text-[#cfd3da] transition hover:border-[#c9932f]/60 hover:text-white"
                  >
                    Replace
                  </button>
                  <button
                    type="button"
                    onClick={onSignatureClear}
                    className="flex-1 rounded border border-[#4a2c2c] px-2 py-1.5 text-xs font-medium text-[#e09a8a] transition hover:border-[#e0684a] hover:text-[#ff9d85]"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => signatureFileRef.current?.click()}
                className="w-full rounded-md border border-dashed border-[#3a3e49] bg-[#171920] px-3 py-4 text-xs font-medium text-[#8f95a1] transition hover:border-[#c9932f]/70 hover:text-[#d8c9a5]"
              >
                + Upload signature image (PNG / JPG)
              </button>
            )}
          </div>
        </Section>

        <p className="px-5 py-4 text-[11px] leading-relaxed text-[#666c78]">
          Recreate and edit your own registration documents. Always verify official records with the
          issuing authority.
        </p>
      </div>
    </div>
  )
}
