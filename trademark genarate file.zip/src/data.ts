import defaultMarkUrl from './assets/mark.png'

export interface CertData {
  actLine: string
  officeLine1: string
  officeLine2: string
  certTitle: string
  watermark: string
  company: string
  companiesAct: string
  address: string
  tmNumber: string
  goods: string
  appliedDate: string
  expiryDate: string
  reservedWords: string
  reservedNote: string
  markLine1: string
  markLine2: string
  markImage: string | null
  sealImage: string | null
  stampDate: string
  signatory: string
  signatoryTitle: string
  signatureImage: string | null
}

export const defaultData: CertData = {
  actLine: 'The Trade Marks Act, Chap 90:01',
  officeLine1: 'COMMERCIAL REGISTRY',
  officeLine2: 'INTELLECTUAL PROPERTY OFFICE',
  certTitle: 'CERTIFICATE OF REGISTRATION OF TRADEMARK',
  watermark: 'DEEDS & COMMERCIAL REGISTRIES AUTHORITY',
  company: 'WE INVEST IN NATIONHOOD (WIN),',
  companiesAct: 'a political party duly registered under the laws of Guyana',
  address: 'Providence, East Bank Demerara, Guyana',
  tmNumber: '45218',
  goods:
    'Political organization, advocacy and campaign services; promotion of political ideas and public policy; printed matter, newspapers, periodicals, books, instructional and teaching materials relating to politics, nationhood, economic development and public affairs; stationery and promotional materials; educational services and dissemination of information concerning national development, local resource retention, support for farmers, small-business entrepreneurs and technical/vocational education; all in International Class 35 and Class 41',
  appliedDate: 'June 23, 2025',
  expiryDate: 'August 18, 2033',
  reservedWords: 'WE INVEST IN NATIONHOOD',
  reservedNote: 'separately and apart from the mark as a whole.',
  markLine1: 'WE INVEST IN NATIONHOOD',
  markLine2: '(WIN)',
  markImage: defaultMarkUrl,
  sealImage: null,
  stampDate: '15 July 2026',
  signatory: 'Gueens Edward',
  signatoryTitle: 'Deputy Registrar',
  signatureImage: null,
}
