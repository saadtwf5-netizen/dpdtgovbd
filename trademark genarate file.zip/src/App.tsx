import { useEffect, useRef, useState } from 'react'
import html2canvas from 'html2canvas'
import { Certificate } from './components/Certificate'
import EditorPanel from './components/EditorPanel'
import { defaultData, type CertData } from './data'

const SHEET_W = 794
const SHEET_H = 1123

type ViewMode = 'fit' | 'width'

export default function App() {
  const [data, setData] = useState<CertData>({ ...defaultData })
  const [scale, setScale] = useState(0.8)
  const [viewMode, setViewMode] = useState<ViewMode>('fit')
  const [exporting, setExporting] = useState(false)
  const previewRef = useRef<HTMLDivElement>(null)
  const wrapRef = useRef<HTMLDivElement>(null)
  const sheetRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = previewRef.current
    if (!el) return
    const update = () => {
      const wScale = (el.clientWidth - 48) / SHEET_W
      if (viewMode === 'width') {
        setScale(Math.max(0.2, Math.min(wScale, 1.1)))
        return
      }
      const hScale = (el.clientHeight - 100) / SHEET_H
      setScale(Math.max(0.2, Math.min(wScale, hScale, 1.1)))
    }
    update()
    const ro = new ResizeObserver(update)
    ro.observe(el)
    return () => ro.disconnect()
  }, [viewMode])

  const setField = (key: keyof CertData, value: string) => setData((d) => ({ ...d, [key]: value }))

  const handleLogo = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => setData((d) => ({ ...d, markImage: String(reader.result) }))
    reader.readAsDataURL(file)
  }

  const handleSeal = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => setData((d) => ({ ...d, sealImage: String(reader.result) }))
    reader.readAsDataURL(file)
  }

  const handleSignature = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => setData((d) => ({ ...d, signatureImage: String(reader.result) }))
    reader.readAsDataURL(file)
  }

  const handleReset = () => setData({ ...defaultData })

  const handlePrint = () => window.print()

  const handlePng = async () => {
    const sheet = sheetRef.current
    const wrap = wrapRef.current
    if (!sheet || !wrap || exporting) return
    setExporting(true)
    const prevTransform = wrap.style.transform
    wrap.style.transform = 'none'
    await document.fonts.ready
    try {
      const canvas = await html2canvas(sheet, {
        scale: 2,
        backgroundColor: '#fbfbf7',
        useCORS: true,
        logging: false,
      })
      const a = document.createElement('a')
      a.download = 'certificate-of-registration-of-trademark.png'
      a.href = canvas.toDataURL('image/png')
      a.click()
    } catch (err) {
      console.error('PNG export failed', err)
    } finally {
      wrap.style.transform = prevTransform
      setExporting(false)
    }
  }

  return (
    <div className="flex h-screen min-h-[560px] flex-col overflow-hidden bg-[#0f1013] text-[#e9e7e1]">
      {/* Top bar */}
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-[#22242b] bg-[#15161b] px-4 sm:px-5 print:hidden">
        <div className="flex items-center gap-3">
          <svg viewBox="0 0 32 32" className="h-8 w-8" aria-hidden="true">
            <circle cx="16" cy="16" r="14.5" fill="none" stroke="#c9932f" strokeWidth="1.6" />
            <circle cx="16" cy="16" r="10" fill="none" stroke="#c9932f" strokeWidth="0.9" />
            <path d="M16 8.5l2 4.4 4.8.5-3.6 3.2 1 4.7-4.2-2.5-4.2 2.5 1-4.7-3.6-3.2 4.8-.5z" fill="#c9932f" />
          </svg>
          <div>
            <h1 className="text-[15px] font-bold leading-tight tracking-tight text-[#f0eee8]">
              Registry Certificate Studio
            </h1>
            <p className="hidden text-[11px] leading-tight text-[#8a909c] sm:block">
              Certificate of Registration of Trade Mark · live editor
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 rounded-md px-3 py-2 text-xs font-semibold text-[#9aa0ab] transition hover:bg-[#22242c] hover:text-white"
            title="Restore the original values"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 12a9 9 0 1 0 3-6.7" />
              <path d="M3 4v5h5" />
            </svg>
            <span className="hidden sm:inline">Reset</span>
          </button>
          <button
            type="button"
            onClick={handlePng}
            disabled={exporting}
            className="flex items-center gap-1.5 rounded-md bg-[#c9932f] px-3.5 py-2 text-xs font-bold text-[#1c1508] shadow-[0_2px_10px_rgba(201,147,47,0.25)] transition hover:bg-[#d9a43f] disabled:opacity-60"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 3v12" />
              <path d="M7 11l5 5 5-5" />
              <path d="M4 19h16" />
            </svg>
            {exporting ? 'Rendering…' : <span className="hidden sm:inline">Download PNG</span>}
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 rounded-md border border-[#3a3d46] px-3.5 py-2 text-xs font-semibold text-[#d6d3cb] transition hover:border-[#585c68] hover:bg-[#1d1f26] hover:text-white"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 9V3h12v6" />
              <rect x="6" y="14" width="12" height="7" rx="1" />
              <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" />
            </svg>
            <span className="hidden sm:inline">Print / Save PDF</span>
          </button>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col-reverse lg:flex-row">
        {/* Editor */}
        <aside className="w-full border-t border-[#22242b] bg-[#121318] lg:h-auto lg:w-[380px] lg:shrink-0 lg:border-r lg:border-t-0 print:hidden">
          <div className="h-[46vh] lg:h-[calc(100vh-56px)]">
            <EditorPanel
              data={data}
              onField={setField}
              onLogo={handleLogo}
              onLogoClear={() => setData((d) => ({ ...d, markImage: null }))}
              onSeal={handleSeal}
              onSealClear={() => setData((d) => ({ ...d, sealImage: null }))}
              onSignature={handleSignature}
              onSignatureClear={() => setData((d) => ({ ...d, signatureImage: null }))}
            />
          </div>
        </aside>

        {/* Preview — the whole sheet fits on one page */}
        <main
          ref={previewRef}
          className="min-h-0 flex-1 overflow-auto bg-[#0d0e11] print:overflow-visible print:bg-white"
        >
          <div className="flex min-h-full flex-col">
            <div className="flex shrink-0 items-center justify-between px-6 pt-3.5 pb-1 print:hidden">
              <span className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#666c78]">
                Live preview
              </span>
              <div className="flex items-center gap-3">
                <div className="flex rounded-md border border-[#26282f] bg-[#15161b] p-0.5 text-[11px] font-semibold">
                  <button
                    type="button"
                    onClick={() => setViewMode('fit')}
                    className={
                      'rounded px-2.5 py-1 transition ' +
                      (viewMode === 'fit'
                        ? 'bg-[#2a2d35] text-[#e9e7e1]'
                        : 'text-[#7d838f] hover:text-[#c5c9d1]')
                    }
                  >
                    Fit page
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode('width')}
                    className={
                      'rounded px-2.5 py-1 transition ' +
                      (viewMode === 'width'
                        ? 'bg-[#2a2d35] text-[#e9e7e1]'
                        : 'text-[#7d838f] hover:text-[#c5c9d1]')
                    }
                  >
                    Full width
                  </button>
                </div>
                <span className="hidden text-[11px] text-[#565c68] md:inline">A4 · 1 page</span>
              </div>
            </div>

            <div className="flex flex-1 px-4 pb-5 pt-2 print:flex-none print:p-0">
              <div className="m-auto">
                <div
                  style={{ width: SHEET_W * scale, height: SHEET_H * scale }}
                  className="print:h-auto! print:w-auto!"
                >
                <div
                  ref={wrapRef}
                  style={{ transform: `scale(${scale})`, transformOrigin: 'top left' }}
                  className="print:transform-none!"
                >
                    <div className="shadow-[0_30px_90px_rgba(0,0,0,0.6)] ring-1 ring-white/10 print:shadow-none print:ring-0">
                      <Certificate ref={sheetRef} data={data} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
